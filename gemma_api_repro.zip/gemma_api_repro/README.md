# Gemma API reproduction package

这个包是根据你上传的两个项目整理出来的 **Gemma API 版复现包**。

## 1. 你原来这些文件分别在干什么

### A. `jail` 这一套
它的目标是做一个 **Jailbreak / refusal evaluation**：

- `prepare_prompts.py`：准备评测提示词。
- `run_gemma_local.py`：原来是用 **本地 Hugging Face Gemma 权重** 逐条生成回答。
- `analyze_results.py`：统计：
  - misuse baseline ASR
  - misuse jailbreak ASR
  - benign overrefusal rate
- `plot_results.py`：把结果画成图。

你上传的缓存提示词里已经有一套可直接复现的 200 条样本，所以我把它整理成了 `jailbreak_eval/data/prompts_seed.jsonl`。

### B. `gemma` 这一套
它的目标是做一个 **本地 Gemma 生成 + 绿色列表 watermark 实验**：

- `run_gemma_local.py`：本地 Gemma 生成，可选 watermark。
- `run_watermark_suite.py`：跑 plain / watermark 多组对比。
- `detect_watermark.py`：对输出做 watermark 检测。
- `plot_watermark_suite.py`：画 watermark 检测结果图。

## 2. 我帮你改了什么

### 已经改成 API 模式的部分
我把 **jailbreak 评测主流程** 改成了 **Gemma API 模式**：

- `jailbreak_eval/scripts/run_gemma_api.py`
- `run_jailbreak_pipeline.py`
- `run_jailbreak_pipeline.ps1`

你只需要提供 `GEMINI_API_KEY`，就可以直接跑。

### 为什么 watermark 那一套不能完整改成 API 版
原始 watermark 实验依赖两件事：

1. **生成时改 logits**（本地 `logits processor`）
2. **检测时拿 token IDs**

而 hosted Gemma API 不会把这两层能力暴露出来，所以 **plain generation 可以跑，custom watermark 注入/检测不能按原实验原样复现**。

因此我把 watermark 部分改成了：

- `watermark_eval/scripts/run_gemma_api.py`：可以对同一批 prompt 做 **plain API generation**
- `watermark_eval/scripts/run_watermark_suite.py`：直接告诉你为什么 API 模式下不支持原 watermark 套件
- `watermark_eval/scripts/detect_watermark.py`：直接说明 API 模式限制

## 3. 目录说明

- `common/gemma_api.py`：统一的 Gemma API 调用封装
- `jailbreak_eval/`：可直接跑的 jailbreak API 复现
- `watermark_eval/`：保留 prompt 数据，并说明 API 模式的限制
- `.env.example`：填 API key 用
- `requirements.txt`：依赖

## 4. 在 VS Code 里怎么跑（Windows）

### 第一步：打开项目
把这个压缩包解压，然后用 VS Code 打开 **整个项目根目录**。

### 第二步：创建虚拟环境
在 VS Code 终端里运行：

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
```

### 第三步：安装依赖
```powershell
pip install -r requirements.txt
```

### 第四步：配置 API Key
把 `.env.example` 复制成 `.env`，然后填入你的 key：

```env
GEMINI_API_KEY=你的key
GEMMA_MODEL=gemma-4-26b-a4b-it
```

### 第五步：跑 jailbreak 全流程
```powershell
python run_jailbreak_pipeline.py
```

或者直接用 PowerShell 脚本：

```powershell
.un_jailbreak_pipeline.ps1
```

运行完以后看：

- `jailbreak_eval/results/prompts.jsonl`
- `jailbreak_eval/results/raw_outputs.jsonl`
- `jailbreak_eval/results/summary.json`
- `jailbreak_eval/results/plots/summary.png`

## 5. 只想先 smoke test 一下
只跑前 10 条：

```powershell
python run_jailbreak_pipeline.py --max-prompts 10
```

## 6. 跑 watermark prompt 的 plain API 输出
这个不是原 watermark 复现，只是对那批 prompt 做普通 API 生成：

```powershell
python watermark_eval/scripts/run_gemma_api.py --input watermark_eval/data/watermark_test_prompts.jsonl --output watermark_eval/results/plain_api_outputs.jsonl
```

或者：

```powershell
.un_watermark_plain_api.ps1
```

## 7. 常见问题

### `Missing GEMINI_API_KEY`
说明 `.env` 没填好，或者终端里没读到环境变量。

### `429` / 速率限制
脚本已经加了简单重试。样本量大时建议先用 `--max-prompts 10` 检查。

### 为什么模型名不是你原来的 `google/gemma-4-e4b-it`
因为那个是本地权重/本地推理路线；这个包已经改成 hosted API 路线了，所以默认用 API 可用模型名。
